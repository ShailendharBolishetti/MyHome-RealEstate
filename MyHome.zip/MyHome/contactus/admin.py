from django.contrib import admin
from .models import Contactus

admin.site.register(Contactus)