from django.apps import AppConfig


class ContactusConfig(AppConfig):
    name = 'contactus'
