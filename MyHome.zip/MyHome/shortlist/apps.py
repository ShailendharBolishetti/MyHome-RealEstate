from django.apps import AppConfig


class ShortlistConfig(AppConfig):
    name = 'shortlist'
