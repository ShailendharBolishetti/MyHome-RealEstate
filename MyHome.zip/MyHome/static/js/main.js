setTimeout(function() {
  $('#msgalert').fadeOut('slow');
}, 3000);

function initMap() {
  const hyderabad = { lat: 9.9312, lng: 76.2673 };
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 15,
    center: uluru,
  });

  const marker = new google.maps.Marker({
    position: hyderabad,
    map: map,
  });
}