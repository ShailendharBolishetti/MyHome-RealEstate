'use strict';
window.django = {jQuery: jQuery.noConflict(true)};
