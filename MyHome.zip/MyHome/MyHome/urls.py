from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('api/listings', include('listings.api.urls')),
    path('api/contactus', include('contactus.api.urls')),
    path('api/accounts', include('accounts.api.urls')),

    

    path('', include('pages.urls')),
    path('listings/', include('listings.urls')),
    path('contactus/', include('contactus.urls')),
    path('accounts/', include('accounts.urls')),
    path('shortlist/', include('shortlist.urls')),
    path('accounts/social/', include('allauth.urls')),
    path('admin/', admin.site.urls),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
