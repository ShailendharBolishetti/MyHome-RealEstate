from django.db import models
from django.contrib.auth.models import User
from django_resized import ResizedImageField

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    photo_user = ResizedImageField(size=[600, 600], upload_to='photos/user/propic', blank=False, default='photos/user/propic/user.png')
    address = models.CharField(max_length=200, blank=False, default="Gachibowli, Hyderabad")
    phone = models.CharField(max_length=200, blank=False, default="6302755514")

    def __str__(self):
        return self.user.username